<?php
session_start();
require_once 'db_config.php';
if (!isset($_SESSION['student_id'])) {
    header('Location: student_login.html');
    exit;
}
$student_id = $_SESSION['student_id'];
$student_name = $_SESSION['student_name'];

$stmt = $conn->prepare("SELECT id, certificate_type, status, request_date, delivery_method, urgency, purpose FROM certificate_requests WHERE student_id = ? ORDER BY request_date DESC");
$stmt->bind_param("i", $student_id);
$stmt->execute();
$res = $stmt->get_result();
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <title>My Requests - CertGenius</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
      <a class="navbar-brand" href="DT.html"><i class="fas fa-certificate me-2"></i>CertGenius</a>
      <div class="d-flex">
        <a class="btn btn-outline-light btn-sm me-2" href="DT.html"><i class="fas fa-home me-1"></i> Home</a>
        <a class="btn btn-outline-light btn-sm me-2" href="student_home.php">Back to Dashboard</a>
        <span class="navbar-text text-white"><?php echo htmlspecialchars($student_name); ?></span>
      </div>
    </div>
  </nav>

  <div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
      <h3>My Certificate Requests</h3>
      <a href="student_home.php" class="btn btn-primary">
        <i class="fas fa-arrow-left me-1"></i> Back to Dashboard
      </a>
    </div>
    