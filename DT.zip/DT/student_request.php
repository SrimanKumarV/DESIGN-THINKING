<?php
// student_request.php - handles certificate request submission
session_start();
require_once 'db_config.php';

if (!isset($_SESSION['student_id'])) {
    header('Location: student_login.html');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: student_home.php');
    exit;
}

$student_id = $_SESSION['student_id'];
$certificate_type = trim($_POST['certificate_type'] ?? '');
$purpose = trim($_POST['purpose'] ?? '');
$delivery_method = $_POST['delivery_method'] ?? 'digital';
$urgency = $_POST['urgency'] ?? 'normal';

// Debug: Check if data is received
error_log("Student ID: $student_id");
error_log("Certificate Type: $certificate_type");
error_log("Purpose: $purpose");
error_log("Delivery Method: $delivery_method");
error_log("Urgency: $urgency");

if ($certificate_type === '' || $purpose === '') {
    echo "<script>alert('Please fill all required fields.'); window.history.back();</script>";
    exit;
}

$stmt = $conn->prepare("INSERT INTO certificate_requests (student_id, certificate_type, purpose, delivery_method, urgency, status) VALUES (?, ?, ?, ?, ?, 'Pending')");
$stmt->bind_param("issss", $student_id, $certificate_type, $purpose, $delivery_method, $urgency);

if ($stmt->execute()) {
    // Get the inserted request ID
    $request_id = $stmt->insert_id;
    
    // Create notification for admin (optional)
    $admin_notification = "New certificate request #$request_id submitted by student ID: $student_id";
    
    // Success: redirect with success message
    header("Location: student_home.php?msg=request_submitted&request_id=$request_id");
    exit;
} else {
    error_log("Database Error: " . $stmt->error);
    echo "<script>alert('Error submitting request. Please try again.'); window.history.back();</script>";
}

$stmt->close();
$conn->close();
?>