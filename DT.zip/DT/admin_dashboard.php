<?php
session_start();
require_once 'db_config.php';
if (!isset($_SESSION['admin_id'])) {
    header('Location: admin_login.html');
    exit;
}
$admin_username = $_SESSION['admin_username'];

// Check for success/error messages
$success_msg = $_SESSION['success_msg'] ?? '';
$error_msg = $_SESSION['error_msg'] ?? '';
// Clear messages after displaying
unset($_SESSION['success_msg']);
unset($_SESSION['error_msg']);

// Get filter if any
$filter = $_GET['filter'] ?? '';

// Build query based on filter - DEFAULT SHOW ONLY PENDING REQUESTS
if (empty($filter)) {
    $filter = 'pending'; // Default to show pending requests
}

$where_clause = "";
if ($filter === 'pending') {
    $where_clause = "WHERE cr.status = 'Pending'";
} elseif ($filter === 'approved') {
    $where_clause = "WHERE cr.status = 'Approved'";
} elseif ($filter === 'rejected') {
    $where_clause = "WHERE cr.status = 'Rejected'";
} elseif ($filter === 'all') {
    $where_clause = ""; // Show all requests
}

// fetch pending + counts
$stmt = $conn->prepare("SELECT 
    SUM(status = 'Pending') AS pending,
    SUM(status = 'Approved') AS approved,
    SUM(status = 'Rejected') AS rejected,
    COUNT(*) AS total
    FROM certificate_requests");
$stmt->execute();
$stmt->bind_result($pending, $approved, $rejected, $total);
$stmt->fetch();
$stmt->close();

// fetch requests with student information
$q = "SELECT cr.id, cr.certificate_type, cr.status, cr.request_date, cr.urgency, cr.delivery_method, cr.purpose, s.name, s.regno, s.email, s.department
      FROM certificate_requests cr
      JOIN students s ON cr.student_id = s.id
      $where_clause
      ORDER BY cr.request_date DESC";
$res = $conn->query($q);
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Admin Dashboard - CertGenius</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
      <a class="navbar-brand" href="DT.html"><i class="fas fa-certificate me-2"></i>CertGenius Admin</a>
      <div class="d-flex">
        <span class="navbar-text text-white me-3">Welcome, <?php echo htmlspecialchars($admin_username); ?></span>
        <a class="btn btn-outline-light btn-sm me-2" href="DT.html"><i class="fas fa-home me-1"></i> Home</a>
        <a class="btn btn-outline-light btn-sm" href="logout.php">Logout</a>
      </div>
    </div>
  </nav>

  <div class="container py-4">
    <!-- Success/Error Messages -->
    <?php if ($success_msg): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
      <i class="fas fa-check-circle me-2"></i><?php echo $success_msg; ?>
      <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php endif; ?>
    
    <?php if ($error_msg): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
      <i class="fas fa-exclamation-triangle me-2"></i><?php echo $error_msg; ?>
      <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php endif; ?>

    <!-- Header with Create Student Button -->
    <div class="d-flex justify-content-between align-items-center mb-4">
      <h3>Admin Dashboard</h3>
      <div>
        <a href="create_student.html" class="btn btn-warning me-2">
          <i class="fas fa-user-plus me-1"></i>Create Student
        </a>
        <a href="DT.html" class="btn btn-outline-primary">
          <i class="fas fa-home me-1"></i> Home
        </a>
      </div>
    </div>
    
    <!-- Stats Cards -->
    <div class="row mb-4">
      <div class="col-md-3">
        <div class="card">
          <div class="card-body stats-card">
            <div class="stats-number"><?php echo (int)$total; ?></div>
            <div class="stats-label">Total Requests</div>
          </div>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card">
          <div class="card-body stats-card">
            <div class="stats-number"><?php echo (int)$pending; ?></div>
            <div class="stats-label">Pending Requests</div>
          </div>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card">
          <div class="card-body stats-card">
            <div class="stats-number"><?php echo (int)$approved; ?></div>
            <div class="stats-label">Approved Requests</div>
          </div>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card">
          <div class="card-body stats-card">
            <div class="stats-number"><?php echo (int)$rejected; ?></div>
            <div class="stats-label">Rejected Requests</div>
          </div>
        </div>
      </div>
    </div>

    <!-- Certificate Requests Table -->
    <div class="card">
      <div class="card-header d-flex justify-content-between align-items-center">
        <span>
          Certificate Requests Management 
          <?php if ($filter === 'pending'): ?>
            - <span class="text-warning">Pending Requests (Action Required)</span>
          <?php elseif ($filter === 'approved'): ?>
            - <span class="text-success">Approved Requests</span>
          <?php elseif ($filter === 'rejected'): ?>
            - <span class="text-danger">Rejected Requests</span>
          <?php else: ?>
            - <span class="text-info">All Requests</span>
          <?php endif; ?>
        </span>
        <div>
          <a href="admin_dashboard.php?filter=pending" class="btn btn-sm <?php echo $filter === 'pending' ? 'btn-warning' : 'btn-outline-warning'; ?> me-1">
            <i class="fas fa-clock me-1"></i>Pending (<?php echo (int)$pending; ?>)
          </a>
          <a href="admin_dashboard.php?filter=approved" class="btn btn-sm <?php echo $filter === 'approved' ? 'btn-success' : 'btn-outline-success'; ?> me-1">
            <i class="fas fa-check me-1"></i>Approved (<?php echo (int)$approved; ?>)
          </a>
          <a href="admin_dashboard.php?filter=rejected" class="btn btn-sm <?php echo $filter === 'rejected' ? 'btn-danger' : 'btn-outline-danger'; ?> me-1">
            <i class="fas fa-times me-1"></i>Rejected (<?php echo (int)$rejected; ?>)
          </a>
          <a href="admin_dashboard.php?filter=all" class="btn btn-sm <?php echo $filter === 'all' ? 'btn-info' : 'btn-outline-info'; ?>">
            <i class="fas fa-list me-1"></i>All Requests
          </a>
        </div>
      </div>
      <div class="card-body">
        <?php if ($res->num_rows > 0): ?>
        <div class="table-responsive">
          <table class="table table-hover table-striped">
            <thead class="table-dark">
              <tr>
                <th>Request ID</th>
                <th>Student Details</th>
                <th>Certificate Type</th>
                <th>Purpose</th>
                <th>Delivery</th>
                <th>Urgency</th>
                <th>Status</th>
                <th>Request Date</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php while ($r = $res->fetch_assoc()) {
                $badge = $r['status'] === 'Approved' ? 'success' : ($r['status'] === 'Rejected' ? 'danger' : 'warning');
                $status_icon = $r['status'] === 'Approved' ? 'fa-check' : ($r['status'] === 'Rejected' ? 'fa-times' : 'fa-clock');
              ?>
              <tr>
                <td><strong>#<?php echo $r['id']; ?></strong></td>
                <td>
                  <div class="student-info">
                    <strong><?php echo htmlspecialchars($r['name']); ?></strong><br>
                    <small class="text-muted">
                      <i class="fas fa-id-card me-1"></i><?php echo htmlspecialchars($r['regno']); ?><br>
                      <i class="fas fa-envelope me-1"></i><?php echo htmlspecialchars($r['email']); ?>
                    </small>
                  </div>
                </td>
                <td><?php echo htmlspecialchars($r['certificate_type']); ?></td>
                <td>
                  <span class="d-inline-block text-truncate" style="max-width: 200px;" title="<?php echo htmlspecialchars($r['purpose']); ?>">
                    <?php echo htmlspecialchars($r['purpose']); ?>
                  </span>
                </td>
                <td>
                  <span class="badge bg-info">
                    <i class="fas fa-<?php echo $r['delivery_method'] === 'digital' ? 'file-pdf' : 'box'; ?> me-1"></i>
                    <?php echo htmlspecialchars(ucfirst($r['delivery_method'])); ?>
                  </span>
                </td>
                <td>
                  <?php 
                  $urgency_badge = $r['urgency'] === 'urgent' ? 'danger' : ($r['urgency'] === 'express' ? 'warning' : 'secondary');
                  $urgency_icon = $r['urgency'] === 'urgent' ? 'fa-fire' : ($r['urgency'] === 'express' ? 'fa-bolt' : 'fa-clock');
                  ?>
                  <span class="badge bg-<?php echo $urgency_badge; ?>">
                    <i class="fas <?php echo $urgency_icon; ?> me-1"></i>
                    <?php echo htmlspecialchars(ucfirst($r['urgency'])); ?>
                  </span>
                </td>
                <td>
                  <span class="badge bg-<?php echo $badge; ?>">
                    <i class="fas <?php echo $status_icon; ?> me-1"></i>
                    <?php echo htmlspecialchars($r['status']); ?>
                  </span>
                </td>
                <td>
                  <small>
                    <?php echo date('d M Y H:i', strtotime($r['request_date'])); ?>
                  </small>
                </td>
                <td>
                  <?php if ($r['status'] === 'Pending') { ?>
                    <div class="btn-group btn-group-sm">
                      <a class="btn btn-success" href="approve_request.php?id=<?php echo $r['id']; ?>" onclick="return confirm('Approve request #<?php echo $r['id']; ?> from <?php echo htmlspecialchars($r['name']); ?>?')" title="Approve">
                        <i class="fas fa-check"></i> Approve
                      </a>
                      <a class="btn btn-danger" href="reject_request.php?id=<?php echo $r['id']; ?>" onclick="return confirm('Reject request #<?php echo $r['id']; ?> from <?php echo htmlspecialchars($r['name']); ?>?')" title="Reject">
                        <i class="fas fa-times"></i> Reject
                      </a>
                    </div>
                  <?php } else { 
                    echo '<span class="text-muted"><i class="fas fa-check-circle me-1"></i>Processed</span>';
                  } ?>
                </td>
              </tr>
              <?php } ?>
            </tbody>
          </table>
        </div>
        <?php else: ?>
          <div class="text-center py-5">
            <i class="fas fa-inbox fa-4x text-muted mb-3"></i>
            <h5 class="text-muted">No Certificate Requests Found</h5>
            <p class="text-muted">
              <?php 
              if ($filter === 'pending') {
                echo "There are no pending certificate requests. All requests have been processed.";
              } elseif ($filter === 'approved') {
                echo "No approved certificate requests found.";
              } elseif ($filter === 'rejected') {
                echo "No rejected certificate requests found.";
              } else {
                echo "No certificate requests have been submitted yet.";
              }
              ?>
            </p>
            <?php if ($filter !== 'pending'): ?>
              <a href="admin_dashboard.php?filter=pending" class="btn btn-primary">
                <i class="fas fa-clock me-1"></i>View Pending Requests
              </a>
            <?php endif; ?>
          </div>
        <?php endif; ?>
      </div>
    </div>

    <!-- Quick Info -->
    <div class="row mt-4">
      <div class="col-md-12">
        <div class="card">
          <div class="card-header bg-dark text-white">
            <h6 class="mb-0"><i class="fas fa-info-circle me-2"></i>Quick Information</h6>
          </div>
          <div class="card-body">
            <div class="row text-center">
              <div class="col-md-4">
                <div class="text-warning">
                  <i class="fas fa-clock fa-2x mb-2"></i>
                  <h5><?php echo (int)$pending; ?> Pending</h5>
                  <small class="text-muted">Requests awaiting action</small>
                </div>
              </div>
              <div class="col-md-4">
                <div class="text-success">
                  <i class="fas fa-check-circle fa-2x mb-2"></i>
                  <h5><?php echo (int)$approved; ?> Approved</h5>
                  <small class="text-muted">Requests approved</small>
                </div>
              </div>
              <div class="col-md-4">
                <div class="text-danger">
                  <i class="fas fa-times-circle fa-2x mb-2"></i>
                  <h5><?php echo (int)$rejected; ?> Rejected</h5>
                  <small class="text-muted">Requests rejected</small>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <script>
    // Auto-refresh the page every 30 seconds to show updated counts
    setTimeout(function() {
      window.location.reload();
    }, 30000); // 30 seconds
  </script>
</body>
</html>
<?php
$conn->close();
?>