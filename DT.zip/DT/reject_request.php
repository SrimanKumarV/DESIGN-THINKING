<?php
// reject_request.php
session_start();
require_once 'db_config.php';
if (!isset($_SESSION['admin_id'])) {
    header('Location: admin_login.html');
    exit;
}

$id = intval($_GET['id'] ?? 0);
if ($id <= 0) {
    header('Location: admin_dashboard.php');
    exit;
}

// Get request details for notification
$stmt = $conn->prepare("SELECT cr.student_id, cr.certificate_type, s.name, s.email 
                       FROM certificate_requests cr 
                       JOIN students s ON cr.student_id = s.id 
                       WHERE cr.id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$stmt->bind_result($student_id, $certificate_type, $student_name, $student_email);
$stmt->fetch();
$stmt->close();

// Update status to Rejected
$stmt = $conn->prepare("UPDATE certificate_requests SET status = 'Rejected' WHERE id = ?");
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    // Create notification for student
    $notification_msg = "Your $certificate_type request (#$id) has been REJECTED. Please contact administration for more details.";
    $notif_stmt = $conn->prepare("INSERT INTO notifications (student_id, message) VALUES (?, ?)");
    $notif_stmt->bind_param("is", $student_id, $notification_msg);
    $notif_stmt->execute();
    $notif_stmt->close();
    
    // Success message
    $_SESSION['success_msg'] = "Request #$id has been rejected successfully! Student has been notified. The request has been moved to Rejected list.";
} else {
    $_SESSION['error_msg'] = "Error rejecting request: " . $stmt->error;
}
// ... existing code ...

if ($stmt->execute()) {
    // Try to create notification (with error handling)
    try {
        $notification_msg = "Your $certificate_type request (#$id) has been APPROVED! You can download your certificate from the dashboard.";
        $notif_stmt = $conn->prepare("INSERT INTO notifications (student_id, message) VALUES (?, ?)");
        if ($notif_stmt) {
            $notif_stmt->bind_param("is", $student_id, $notification_msg);
            $notif_stmt->execute();
            $notif_stmt->close();
        }
    } catch (Exception $e) {
        // Notifications table doesn't exist - continue without notification
        error_log("Notification error: " . $e->getMessage());
    }
    
    // Success message
    $_SESSION['success_msg'] = "Request #$id has been approved successfully!" . (isset($notif_stmt) ? " Student has been notified." : "");
} else {
    $_SESSION['error_msg'] = "Error approving request: " . $stmt->error;
}

// ... rest of the code ...
$stmt->close();
$conn->close();

// Redirect back to pending requests
header('Location: admin_dashboard.php?filter=pending');
exit;
?>